let socket = io();

document.getElementById('bid-btn').onclick = () => {
  socket.emit('placeBid', { amount: 10 });
};

document.getElementById('pass-btn').onclick = () => {
  socket.emit('passTurn');
};

socket.on('leaderboard', (data) => {
  document.getElementById('leaderboard').innerText =
    `Player 1: ${data.player1Score} | Player 2: ${data.player2Score}`;
});

socket.on('updatePlayerCards', (players) => {
  let container = document.getElementById('player-cards');
  container.innerHTML = '';
  players.forEach(p => {
    container.innerHTML += `<div><h3>${p.name}</h3><p>${p.role}</p></div>`;
  });
});
