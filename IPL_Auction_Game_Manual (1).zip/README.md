# IPL Auction Game

A basic IPL Auction Game with multiplayer support using Node.js and Socket.IO.

## Run Locally
1. Install Node.js
2. Run in terminal:
   npm install
   npm start
3. Open browser at: http://localhost:3000
