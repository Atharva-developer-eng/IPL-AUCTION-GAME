const express = require('express');
const http = require('http');
const socketIo = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = socketIo(server);

app.use(express.static('public'));

let players = [
  { name: 'Virat Kohli', role: 'Batsman' },
  { name: 'MS Dhoni', role: 'Wicketkeeper' },
  { name: 'Rohit Sharma', role: 'Batsman' },
  { name: 'Hardik Pandya', role: 'All-Rounder' }
];

let player1Score = 0;
let player2Score = 0;

io.on('connection', (socket) => {
  socket.emit('updatePlayerCards', players);

  socket.on('placeBid', () => {
    player1Score += 10;
    io.emit('leaderboard', { player1Score, player2Score });
  });

  socket.on('passTurn', () => {
    console.log('Turn passed');
  });
});

server.listen(3000, () => console.log('Running on http://localhost:3000'));
